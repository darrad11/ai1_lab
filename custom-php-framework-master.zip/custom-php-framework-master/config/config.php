<?php
$config = [];
$config['db_dsn'] = 'sqlite:C:\Users\darra\Desktop\Studia_ZUT\SEM5\Aplikacje_Internetowe\lab\lab6-php\custom-php-framework-master\data.db';
$config['db_user'] = '';
$config['db_pass'] = '';
