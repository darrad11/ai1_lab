<?php
namespace App\Exception;

class ConfigException extends FrameworkException
{

}
