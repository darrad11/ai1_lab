/* rd51625 grN1 script.ts */

function greet(name: string): string {
    return `Hello, ${name}!`;
}

/*function zmienStyl(nazwaStylu) {
	document.getElementById('stylCSS').href = nazwaStylu;
	window.scrollTo(0, 0);
}*/

function zmienStyl(nazwaStylu: string): void {
	const stylCSS = document.getElementById('stylCSS') as HTMLLinkElement | null;
	if(stylCSS) {
		stylCSS.href = nazwaStylu;
		window.scrollTo(0, 0);
	}
}

document.addEventListener('DOMContentLoaded', () => {
	const Button1 = document.getElementById('Button1');
	const Button2 = document.getElementById('Button2');
	const Button3 = document.getElementById('Button3');
	
	if(Button1) {
		Button1.addEventListener('click', () => zmienStyl('rwd.css'));
	}
	if(Button2) {
		Button2.addEventListener('click', () => zmienStyl('css1.css'));
	}
	if(Button3) {
		Button3.addEventListener('click', () => zmienStyl('css2.css'));
	}
});

console.log(greet("World"));